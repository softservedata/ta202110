﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProjectTA
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Console.WriteLine("start");
            CalcServiceReference.CalcSEIClient calc = new CalcServiceReference.CalcSEIClient();
            double expected = 6;
            double actual = calc.add(1, 2);
            Assert.AreEqual(expected, actual);
        }
    }
}
