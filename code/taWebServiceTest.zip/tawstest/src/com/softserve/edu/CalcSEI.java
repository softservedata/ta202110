/**
 * CalcSEI.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.softserve.edu;

public interface CalcSEI extends java.rmi.Remote {
    public double add(double arg0, double arg1) throws java.rmi.RemoteException;
}
