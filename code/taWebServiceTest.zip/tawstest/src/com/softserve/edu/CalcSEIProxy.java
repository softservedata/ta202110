package com.softserve.edu;

public class CalcSEIProxy implements com.softserve.edu.CalcSEI {
  private String _endpoint = null;
  private com.softserve.edu.CalcSEI calcSEI = null;
  
  public CalcSEIProxy() {
    _initCalcSEIProxy();
  }
  
  public CalcSEIProxy(String endpoint) {
    _endpoint = endpoint;
    _initCalcSEIProxy();
  }
  
  private void _initCalcSEIProxy() {
    try {
      calcSEI = (new com.softserve.edu.CalcServiceLocator()).getCalcPort();
      if (calcSEI != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)calcSEI)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)calcSEI)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (calcSEI != null)
      ((javax.xml.rpc.Stub)calcSEI)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.softserve.edu.CalcSEI getCalcSEI() {
    if (calcSEI == null)
      _initCalcSEIProxy();
    return calcSEI;
  }
  
  public double add(double arg0, double arg1) throws java.rmi.RemoteException{
    if (calcSEI == null)
      _initCalcSEIProxy();
    return calcSEI.add(arg0, arg1);
  }
  
  
}