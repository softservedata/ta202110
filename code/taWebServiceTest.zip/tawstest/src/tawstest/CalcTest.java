package tawstest;

import java.rmi.RemoteException;

import org.junit.Assert;
import org.junit.Test;

import com.softserve.edu.CalcSEI;
import com.softserve.edu.CalcSEIProxy;

public class CalcTest {
	
	@Test
	public void TestAdd() throws RemoteException {
		System.out.println("start");
		//CalcServiceReference.CalcSEIClient calc = new CalcServiceReference.CalcSEIClient();
		CalcSEI calc = new CalcSEIProxy();
		double expected = 10;
		double actual = calc.add(2, 3);
		Assert.assertEquals(expected, actual, 0.001);
	}
}
