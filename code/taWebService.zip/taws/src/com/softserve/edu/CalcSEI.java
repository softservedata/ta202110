package com.softserve.edu;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;
import javax.xml.ws.RequestWrapper;
import javax.xml.ws.ResponseWrapper;

@WebService(name = "CalcSEI", targetNamespace = "http://edu.softserve.com/")
public interface CalcSEI {

	@WebMethod(operationName = "add", action = "urn:Add")
	@RequestWrapper(className = "com.softserve.edu.jaxws.Add", localName = "add", targetNamespace = "http://edu.softserve.com/")
	@ResponseWrapper(className = "com.softserve.edu.jaxws.AddResponse", localName = "addResponse", targetNamespace = "http://edu.softserve.com/")
	@WebResult(name = "return")
	double add(@WebParam(name = "arg0") double arg0, @WebParam(name = "arg1") double arg1);

}