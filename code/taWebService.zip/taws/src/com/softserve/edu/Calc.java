package com.softserve.edu;

import javax.jws.WebService;

@WebService(targetNamespace = "http://edu.softserve.com/", endpointInterface = "com.softserve.edu.CalcSEI", portName = "CalcPort", serviceName = "CalcService")
public class Calc implements CalcSEI {

	public double add(double arg0, double arg1) {
		return (arg0 + arg1) * 2;
	}
	
}
